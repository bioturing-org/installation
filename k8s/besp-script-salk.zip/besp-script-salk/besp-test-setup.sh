#!/bin/bash

export ROOT_DIR=/Users/bioturing/.besp
export CLIENT=bioturing

helm upgrade --install besp ./besp-chart --set hostname=`hostname` --set root_dir=$ROOT_DIR --set client=$CLIENT
kubectl get pods -w