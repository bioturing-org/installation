#!/bin/bash

mkdir -p ~/.kube
chmod ugo+rwx ~/.kube/
chmod ugo+rwx ~/.kube/config

CONTAINER_RUNTIME=crio
if ! hash docker 2>/dev/null; then 
	cp /bin/true /usr/bin/docker
fi
minikube start --kubernetes-version=v1.19.1 \
               --driver=none \
               --container-runtime=$CONTAINER_RUNTIME \
		--extra-config=apiserver.runtime-config=settings.k8s.io/v1alpha1=true

SECRET_DOCKER_TOKEN=dckr_pat_xXtrGyvz7oEmA0UyNSCLQYiIUhQ
kubectl create secret docker-registry regcred \
        --docker-server=https://index.docker.io/v2/  \
        --docker-username=bioturing \
        --docker-password=$SECRET_DOCKER_TOKEN \
        --docker-email=support@bioturing.com

### Install helm 3
HTTP_PORT=32676
curl https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3 | bash
cp /usr/local/bin/helm /usr/bin/helm
export HTTP_PORT=32676
export PATH=/usr/bin:$PATH
helm repo add --insecure-skip-tls-verify ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update
helm list | grep nginx-ingress ; ans=$?
helm install nginx-ingress ingress-nginx/ingress-nginx --set controller.service.nodePorts.http=$HTTP_PORT --version=3.34.0
