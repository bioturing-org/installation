minikube kubectl -- get pods -A

access:
kubectl exec --stdin --tty <pod_name> -- /bin/bash

kubectl get secret
kubectl get pv
kubectl get all -n default

kubectl get pv mysql-pv-volume
kubectl get pv mysql-pv-claim

check error:
kubectl describe pods <pod_name>
kubectl describe pods metadata-74bcd56bb-dtrl8
kubectl logs <pod_name>

Neu ko OK:
minikube tunnel

Check run:
minikube logs

Unisntall:
helm uninstall besp

Check nginx:
minikube delete --all --purge
kubectl --namespace default get services -o wide -w nginx-ingress-ingress-nginx-controller