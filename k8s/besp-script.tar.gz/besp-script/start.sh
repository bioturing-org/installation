#!/bin/bash

export ROOT_DIR=/Users/bioturing/.besp
export CLIENT=bioturing

CONTAINER_RUNTIME=docker
if ! hash docker 2>/dev/null; then 
	cp /bin/true /usr/bin/docker
fi

minikube start --kubernetes-version=v1.19.1 \
               --driver=hyperkit \
               --container-runtime=$CONTAINER_RUNTIME \
		--extra-config=apiserver.runtime-config=settings.k8s.io/v1alpha1=true