#!/bin/bash

mkdir -p ~/.kube
chmod ugo+rwx ~/.kube/
chmod ugo+rwx ~/.kube/config

### Check the environment variables
if [[ -z "${ROOT_DIR}" ]]; then
	echo "Please set the data directory of BESP into the variable ROOT_DIR. e.g export ROOT_DIR=/mnt"
	exit 1;
fi

if [[ -z "${CLIENT}" ]]; then
	echo "Please your institution name into the variable CLIENT. e.g export CLIENT=bioturing"
	exit 1;
fi

if [[ -z "${MYSQL_VOLUME_SIZE}" ]]; then
	echo "Please set the variable MYSQL_VOLUME_SIZE. e.g export MYSQL_VOLUME_SIZE=5Gi"
	exit 1;
fi

if [[ -z "${ROOT_VOLUME_SIZE}" ]]; then
	echo "Please set the variable ROOT_VOLUME_SIZE. e.g export ROOT_VOLUME_SIZE=15Gi"
	exit 1;
fi

set -e 
if [ ! -d "$ROOT_DIR/accountdb" ]; then
	echo "Please create the folder $ROOT_DIR/accountdb"
	exit 1;
fi
set +e
CONTAINER_RUNTIME=crio
if ! hash docker 2>/dev/null; then 
	cp /bin/true /usr/bin/docker
fi
minikube start --kubernetes-version=v1.19.1 \
               --driver=none \
               --container-runtime=$CONTAINER_RUNTIME \
		--extra-config=apiserver.runtime-config=settings.k8s.io/v1alpha1=true

SECRET_DOCKER_TOKEN=dckr_pat_xXtrGyvz7oEmA0UyNSCLQYiIUhQ
kubectl create secret docker-registry regcred \
        --docker-server=https://index.docker.io/v2/  \
        --docker-username=bioturing \
        --docker-password=$SECRET_DOCKER_TOKEN \
        --docker-email=support@bioturing.com

### Install helm 3
HTTP_PORT=32676
curl https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3 | bash
cp /usr/local/bin/helm /usr/bin/helm
export HTTP_PORT=32676
export PATH=/usr/bin:$PATH
helm repo add --insecure-skip-tls-verify ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update
helm list | grep nginx-ingress ; ans=$?
helm install nginx-ingress ingress-nginx/ingress-nginx --set controller.service.nodePorts.http=$HTTP_PORT --version=3.34.0

echo "Apply recipes for BESP..."
set -e 
mkdir -p $ROOT_DIR/accountdb

curl -LO "https://raw.githubusercontent.com/bioturing/installation/main/k8s/besp-chart-2.0.0.tgz"
helm upgrade --install besp ./besp-chart-2.0.0.tgz --set hostname=`hostname` \
	--set root_dir=$ROOT_DIR --set client=$CLIENT \
	--set root_volume_size=$ROOT_VOLUME_SIZE \
	--set mysql_volume_size=$MYSQL_VOLUME_SIZE

kubectl get pods -w