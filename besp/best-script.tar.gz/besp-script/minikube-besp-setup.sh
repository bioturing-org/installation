#!/bin/bash

if [[ -z "${ROOT_DIR}" ]]; then
	echo "Please set the data directory of BESP into the variable ROOT_DIR. e.g export ROOT_DIR=/mnt"
	exit 1;
fi

if [[ -z "${CLIENT}" ]]; then
	echo "Please your institution name into the variable CLIENT. e.g export CLIENT=bioturing"
	exit 1;
fi

if [[ -z "${MYSQL_VOLUME_SIZE}" ]]; then
	echo "Please set the variable MYSQL_VOLUME_SIZE. e.g export MYSQL_VOLUME_SIZE=5Gi"
	exit 1;
fi

if [[ -z "${ROOT_VOLUME_SIZE}" ]]; then
	echo "Please set the variable ROOT_VOLUME_SIZE. e.g export ROOT_VOLUME_SIZE=15Gi"
	exit 1;
fi

if [ ! -d "$ROOT_DIR/accountdb" ]; then
	echo "Create the folder $ROOT_DIR/accountdb"
    mkdir -p $ROOT_DIR/accountdb
fi

curl -LO "https://raw.githubusercontent.com/bioturing/installation/main/k8s/besp-chart-2.0.0.tgz"
helm upgrade --install besp ./besp-chart-2.0.0.tgz --set hostname=`hostname` \
	--set root_dir=$ROOT_DIR --set client=$CLIENT \
	--set root_volume_size=$ROOT_VOLUME_SIZE \
	--set mysql_volume_size=$MYSQL_VOLUME_SIZE

kubectl get pods -w