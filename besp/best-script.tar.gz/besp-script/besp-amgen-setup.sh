#!/bin/bash

export OPT_ROOT_DIR=/scratch/bbrowser
export OPT_CLIENT=amgen
export OPT_MYSQL_VOLUME_SIZE=5Gi
export OPT_ROOT_VOLUME_SIZE=1000Gi

ROOT_DIR=${OPT_ROOT_DIR} CLIENT=${OPT_CLIENT} MYSQL_VOLUME_SIZE=${OPT_MYSQL_VOLUME_SIZE} ROOT_VOLUME_SIZE=${OPT_ROOT_VOLUME_SIZE}  bash ./minikube-besp-setup.sh

kubectl get pods -w